# Linux packaging for Tokkio

## Validated baseline

- Unreal Engine 5.5.4 installed on Windows
- Linux x86_64 target
- Development configuration for the ACE plugin set
- UE 5.5 cross-compile SDK `v23_clang-18.1.0-rockylinux8`
- Archive layout accepted by the Unreal Renderer volume mount

Do not assume that the Epic Launcher Linux Target Platform includes the cross-compile SDK. Verify both.

## Verify the Linux SDK

Run:

```powershell
& '<UE_ROOT>\Engine\Build\BatchFiles\RunUAT.bat' `
  Turnkey -command=VerifySdk -platform=Linux -utf8output
```

Require `Linux: (Status=Valid, ...)`. If invalid, install the exact `Allowed_Sdk` reported by Turnkey from Epic's official Linux Development Requirements page. For UE 5.5.4, the validated version was `v23_clang-18.1.0-rockylinux8`.

Before running a downloaded installer, verify:

```powershell
Get-AuthenticodeSignature <installer>
Get-FileHash <installer> -Algorithm SHA256
```

Require a valid Epic Games signature. Software installation still requires the applicable user approval. After installation, read `LINUX_MULTIARCH_ROOT` from the machine environment and set it in the active PowerShell process before invoking Unreal.

## Package deterministically

Use `scripts/package-linux.ps1`. The validated command is:

```powershell
./scripts/package-linux.ps1 `
  -ProjectRoot <project-root> `
  -EngineRoot 'C:\Program Files\Epic Games\UE_5.5' `
  -ArchiveDirectory <project-root>\dist\Linux
```

Use `-Clean` after an interrupted linker or symbol-generation run. Use `-ValidateOnly` to verify the SDK and an existing archive without rebuilding.

The script intentionally passes:

```text
-NoUBA -NoUBALocal -NoXGE
```

UE 5.5 enables UBALocal separately from UBA. `-NoUBA` alone does not disable it. The validated workstation crashed inside `UbaDetours.dll` while `dump_syms.exe` generated Linux symbols; the standard Parallel executor completed successfully.

The BuildCookRun stage uses:

```text
Development, -nocompileeditor, -nodebuginfo, -allmaps,
-cook, -build, -stage, -prereqs, -pak, -archive, -platform=Linux
```

`-nocompileeditor` avoids rebuilding the Win64-only Reallusion Auto Setup Editor module during Linux packaging. Keep `RLPlugin` for import authoring, but do not require it in the Linux runtime.

## Mandatory archive checks

Require all of the following:

- `<archive>/<module>.sh`
- `<archive>/<module>/Binaries/Linux/<module>` with ELF magic `7F-45-4C-46`
- `<module>-Linux.pak`
- `<module>-Linux.ucas`
- `<module>-Linux.utoc`
- `Plugins/NV_ACE_Reference/ThirdParty/Nvigi/Binaries/Linux`
- AutomationTool `BUILD SUCCESSFUL` and exit code 0

Record the archive file count, total size, main ELF hash, and IoStore hashes when handing off to a Linux host.

## Cook failures after long shader compilation

Read the final `Warning/Error Summary`; do not infer the cause from elapsed time. Derived Data Cache is reusable, so fix the asset problem and rerun without deleting DDC.

If the summary reports a `Failed import` because a native default subobject changed class, such as PointLight to DirectionalLight:

1. run `scripts/create-cc5-tokkio-level.py` with normal GPU rendering;
2. destroy and respawn the avatar actor from the current native class;
3. save the level;
4. load the level again and confirm no `Failed import` remains;
5. rerun packaging without clearing DDC.

Do not use `-NullRHI` when spawning the camera/light actor in the validated UE 5.5 workflow.

## Linux handoff

Transfer the entire archive directory, not only the ELF or Pak files. The launch script sets the executable bit on the binary. On Linux, run the script from its archive root or mount the archive into the Unreal Renderer container at the configured Unreal project resource path.
