# Prerequisites

## Validated Windows baseline

- Unreal Engine 5.5.4
- Visual Studio 2022 Community or higher
- Workload: Game development with C++
- MSVC v143 14.38 build tools
- Windows SDK 10.0.22621
- Unreal Linux Target Platform when producing the Linux/Tokkio package
- Reallusion CC/iC Auto Setup build compatible with UE 5.5
- NVIDIA ACE Unreal Renderer package built for UE 5.5

Treat the engine/plugin pairing as a compatibility contract. Do not silently mix a UE 5.3/5.4/5.6 plugin binary with UE 5.5.

## Required project plugins

| Plugin | Purpose |
|---|---|
| `RLPlugin` | Reallusion Auto Setup import and shader/profile processing |
| `NV_ACE_Reference` | ACE runtime and Audio2Face curve source |
| `ACEUnrealRendererStreamHelper` | Registers the renderer actor used by stream requests |
| `ACEUnrealRendererHttpAPI` | Exposes the local renderer HTTP API, normally on port 8021 |

## Visual Studio checks

Check for:

- `VC/Tools/MSVC/14.38.*`
- `MSBuild/Current/Bin/MSBuild.exe`
- Windows Kits `10/Include/10.0.22621.0`

The exact SDK patch can vary, but record the version UnrealBuildTool actually selects.

## Reallusion Auto Setup

Common Windows installation root:

```text
C:\Program Files\Reallusion\Shared Plugins\Auto Setup\Unreal
```

Use the guide bundled with the installed Auto Setup version. Project placement may include both a `Content` subtree and `RLPlugin`; preserve its directory layout.

## NVIDIA ACE Renderer package

A validated package name was similar to:

```text
NV_ACE_Reference-UE5.5-v2.5.0rc3.zip
```

Package names change. Inspect `.uplugin` files and target engine metadata instead of relying only on the ZIP name.

