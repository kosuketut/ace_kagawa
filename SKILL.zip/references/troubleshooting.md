# Troubleshooting

## Export looks empty

- Check file sizes, not just filenames.
- Inspect sibling `.fbm` folders for the real FBX/JSON/textures.
- Require an FBX binary header and parseable JSON.

## Morphs are missing

- Reimport after explicitly enabling **Import Morph Targets** in Unreal's FBX dialog.
- Confirm CC5 used an extended/ARKit-compatible facial profile.
- Do not infer ARKit compatibility solely from total morph count.

## Auto Setup materials are incomplete

- Confirm `RLPlugin` version matches the engine.
- Keep the JSON next to the FBX and preserve texture-relative paths.
- Distinguish imported-character texture errors from optional MetaHuman sample warnings.

## Headless map creation crashes

Do not spawn an actor containing camera/light components under `-NullRHI` in the validated UE 5.5 setup. A divide-by-zero crash occurred. Create or load the map with normal GPU rendering.

## Python property mismatch

Unreal Python APIs differ by version. Use supported methods rather than guessed properties. For example, an earlier UE 5.3 flow rejected `SkeletalMeshComponent.looping`; use the supported playback API for that engine.

## Build cannot link

- Close Unreal Editor to release project/plugin DLLs.
- Confirm MSVC and SDK versions selected by UnrealBuildTool.
- Rebuild the Editor target after changing plugin or module dependencies.
- Rebuild the Game target after final runtime changes.

## Linux platform is not valid

Run Turnkey `VerifySdk` for Linux. The Launcher Linux Target Platform and the Windows cross-compile SDK are separate requirements. Install the exact `Allowed_Sdk` reported by Turnkey and refresh `LINUX_MULTIARCH_ROOT` in the active process.

## `dump_syms.exe` or `UbaDetours.dll` crashes

Disable both UBA modes and XGE for the Linux target:

```text
-NoUBA -NoUBALocal -NoXGE
```

`-NoUBA` alone leaves UBALocal enabled in UE 5.5. Clean and rebuild the Linux target after a symbol-generation crash so a stale manifest cannot reference a missing `.sym` file.

## Linux build requests `UnrealEditor-RLPlugin.lib`

Use `-nocompileeditor` for BuildCookRun after the Editor target has already been built. `RLPlugin` is a Win64 Editor import tool and is not required in the Linux runtime.

## Cook reports a native component `Failed import`

The saved map can retain instance data for an old default-subobject class. Respawn the avatar actor from the current native class and save the map. Reload it and require zero `Failed import` lines before rerunning Cook.

## Wrong camera side

Verify the skeletal mesh forward axis in Play. A CC5 import can face `+Y`; a camera on the opposite side will show the back of the head. Adjust position and yaw together.

## Light geometry appears behind the face

Inspect the level actor count first. If no extra mesh actor exists, replace the camera-adjacent point light with a directional or rect light and test again.

## `/health` fails

- Start Play; Editor idle mode is insufficient.
- Confirm `ACEUnrealRendererHttpAPI` is enabled and loaded.
- Check whether port 8021 is already in use.
- Read the project log for plugin startup errors.
