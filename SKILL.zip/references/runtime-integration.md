# Unreal runtime integration

## Module dependencies

Add these runtime dependencies to the project module:

```csharp
PublicDependencyModuleNames.AddRange(new string[]
{
    "Core",
    "CoreUObject",
    "Engine",
    "ACERuntime",
    "ACEUnrealRendererStreamHelper"
});
```

## Runtime actor responsibilities

Create a native `AActor` with:

- `USceneComponent` root
- `USkeletalMeshComponent` for the CC5 mesh
- `UACEAudioCurveSourceComponent`
- `UCameraComponent`
- lighting components appropriate to the project renderer

Register the actor:

```cpp
void ACC5TokkioAvatar::BeginPlay()
{
    Super::BeginPlay();
    UACEUnrealRendererStreamHelperLibrary::SetActor(this);

    if (APlayerController* PC = UGameplayStatics::GetPlayerController(this, 0))
    {
        PC->SetViewTarget(this);
    }
}

void ACC5TokkioAvatar::EndPlay(const EEndPlayReason::Type Reason)
{
    if (UACEUnrealRendererStreamHelperLibrary::GetActor() == this)
    {
        UACEUnrealRendererStreamHelperLibrary::ClearActor();
    }
    Super::EndPlay(Reason);
}
```

Apply the curves every tick:

```cpp
TArray<float> Weights;
ACECurveSource->GetCurveOutputsInterp(Weights);
if (Weights.Num() >= 52)
{
    // Use the exact index mapping in ace-cc5-mapping.md.
    CharacterMesh->SetMorphTarget(TargetName, Weights[Index], false);
}
```

For indices 43 and 46, set both left and right CC5 targets.

## Validated camera baseline

For a CC5 character facing `+Y`, a useful starting point was:

```cpp
AvatarCamera->SetRelativeLocation(FVector(0.0, 220.0, 145.0));
AvatarCamera->SetRelativeRotation(FRotator(0.0, -90.0, 0.0));
AvatarCamera->SetFieldOfView(45.0f);
```

This is a starting point, not a universal constant. Verify the character's actual forward axis and bounds in Play. Use head-and-shoulders framing for Tokkio.

Avoid a visible point-light source between the camera and face. Directional or rect lights are safer for a clean renderer frame. If using multiple directional lights, watch for forward/translucency fallback warnings; prefer a key plus a non-directional fill in production.

## Level and maps

Create one level actor and save the map. Configure:

```ini
[/Script/EngineSettings.GameMapsSettings]
EditorStartupMap=/Game/Maps/L_CC5_Tokkio
GameDefaultMap=/Game/Maps/L_CC5_Tokkio
```

Delete stale incomplete map assets before recreating them. Save with `EditorLoadingAndSavingUtils.save_current_level()`.

## Build targets

Build both:

```text
<ModuleName>Editor Win64 Development
<ModuleName> Win64 Development
```

Close Unreal Editor before linking. A running Editor can lock the project and plugin DLLs.

## HTTP verification

Run Play before calling:

```text
GET http://127.0.0.1:8021/health
```

Expected body includes:

```json
{
  "message": "Health Check Successful!",
  "success": true,
  "code": 200
}
```

Health success verifies the local Unreal renderer API only. A full Tokkio test additionally requires the upstream service and a stream creation request.

