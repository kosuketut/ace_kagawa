# CC5 export and Unreal import

## CC5 export

Open the completed character and use the FBX character export flow, normally:

```text
File > Export > FBX > Clothed Character
```

Use these settings or their CC5-version equivalents:

| Area | Setting |
|---|---|
| Target | Unreal Engine preset |
| Content | Character mesh and skeleton |
| Motion | Current pose unless animation export is explicitly needed |
| Facial profile | Extended/ARKit-compatible profile; never `None` |
| Expressions | Export facial blendshapes/morphs |
| Textures | Export textures and Reallusion JSON sidecar |
| Geometry | Keep the original character topology unless an LOD/remesh task was requested |
| Materials | Preserve material separation needed by Auto Setup |

CC5 labels can differ across builds. The output verification is authoritative: require an FBX, matching JSON, texture tree, and the ARKit-compatible morphs after Unreal import.

Do not export only the base body when clothes, eyes, teeth, tongue, tear ducts, or eyelashes are needed.

## Expected export bundle

A healthy export commonly resembles:

```text
CharacterName.fbx
CharacterName.json
textures/
CharacterName.fbm/        # possible alternative/sibling location
```

The JSON should contain an export directory, generation metadata, material definitions, and texture references. Preserve relative texture paths when moving the bundle.

## Unreal import with Auto Setup

1. Open the target project only after the compatible `RLPlugin` is installed and enabled.
2. Start the Reallusion Auto Setup import action.
3. Choose the exported FBX and its JSON sidecar.
4. Keep Auto Setup enabled.
5. Disable Control Rig unless control-rig authoring is required.
6. In the Unreal FBX dialog, enable **Import Morph Targets** explicitly.
7. Use **Import All**.
8. Wait for shader/material/profile processing to finish.
9. Save all imported packages.

## Import evidence

Require at least:

- skeletal mesh
- skeleton
- physics asset
- materials and material instances
- textures and SSS profiles
- Reallusion facial/profile assets when supplied
- morph targets on the skeletal mesh

Warnings about unrelated MetaHuman sample textures can be non-blocking. Distinguish them from missing textures referenced by the imported CC5 materials.

