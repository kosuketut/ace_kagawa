# ACE ARKit 52 to CC5 mapping

Use this order when consuming `UACEAudioCurveSourceComponent::GetCurveOutputsInterp()`.

| Index | ACE curve | CC5 morph target |
|---:|---|---|
| 0 | EyeBlinkLeft | Eye_Blink_L |
| 1 | EyeLookDownLeft | Eye_L_Look_Down |
| 2 | EyeLookInLeft | Eye_L_Look_R |
| 3 | EyeLookOutLeft | Eye_L_Look_L |
| 4 | EyeLookUpLeft | Eye_L_Look_Up |
| 5 | EyeSquintLeft | Eye_Squint_L |
| 6 | EyeWideLeft | Eye_Wide_L |
| 7 | EyeBlinkRight | Eye_Blink_R |
| 8 | EyeLookDownRight | Eye_R_Look_Down |
| 9 | EyeLookInRight | Eye_R_Look_L |
| 10 | EyeLookOutRight | Eye_R_Look_R |
| 11 | EyeLookUpRight | Eye_R_Look_Up |
| 12 | EyeSquintRight | Eye_Squint_R |
| 13 | EyeWideRight | Eye_Wide_R |
| 14 | JawForward | Jaw_Forward |
| 15 | JawLeft | Jaw_L |
| 16 | JawRight | Jaw_R |
| 17 | JawOpen | Jaw_Open |
| 18 | MouthClose | Mouth_Close |
| 19 | MouthFunnel | Mouth_Funnel |
| 20 | MouthPucker | Mouth_Pucker |
| 21 | MouthLeft | Mouth_L |
| 22 | MouthRight | Mouth_R |
| 23 | MouthSmileLeft | Mouth_Smile_L |
| 24 | MouthSmileRight | Mouth_Smile_R |
| 25 | MouthFrownLeft | Mouth_Frown_L |
| 26 | MouthFrownRight | Mouth_Frown_R |
| 27 | MouthDimpleLeft | Mouth_Dimple_L |
| 28 | MouthDimpleRight | Mouth_Dimple_R |
| 29 | MouthStretchLeft | Mouth_Stretch_L |
| 30 | MouthStretchRight | Mouth_Stretch_R |
| 31 | MouthRollLower | Mouth_Roll_In_Lower |
| 32 | MouthRollUpper | Mouth_Roll_In_Upper |
| 33 | MouthShrugLower | Mouth_Shrug_Lower |
| 34 | MouthShrugUpper | Mouth_Shrug_Upper |
| 35 | MouthPressLeft | Mouth_Press_L |
| 36 | MouthPressRight | Mouth_Press_R |
| 37 | MouthLowerDownLeft | Mouth_Down_Lower_L |
| 38 | MouthLowerDownRight | Mouth_Down_Lower_R |
| 39 | MouthUpperUpLeft | Mouth_Up_Upper_L |
| 40 | MouthUpperUpRight | Mouth_Up_Upper_R |
| 41 | BrowDownLeft | Brow_Drop_L |
| 42 | BrowDownRight | Brow_Drop_R |
| 43 | BrowInnerUp | Brow_Raise_Inner_L and Brow_Raise_Inner_R |
| 44 | BrowOuterUpLeft | Brow_Raise_Outer_L |
| 45 | BrowOuterUpRight | Brow_Raise_Outer_R |
| 46 | CheekPuff | Cheek_Puff_L and Cheek_Puff_R |
| 47 | CheekSquintLeft | Cheek_Raise_L |
| 48 | CheekSquintRight | Cheek_Raise_R |
| 49 | NoseSneerLeft | Nose_Sneer_L |
| 50 | NoseSneerRight | Nose_Sneer_R |
| 51 | TongueOut | Tongue_Out |

ACE also exposes head rotation curves in some paths. Treat them separately from the 52 facial weights.

## Validation

Require all 54 CC5 targets referenced by the table: 50 single targets plus two left/right pairs. Match names case-sensitively. Report every missing name before building.

