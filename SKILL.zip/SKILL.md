---
name: build-cc5-tokkio-avatar
description: Export a Character Creator 5 character with facial blendshapes, import it into Unreal Engine with Reallusion Auto Setup, integrate NVIDIA ACE Unreal Renderer plugins, map ACE ARKit 52 curves to CC5 morph targets, build and verify the Tokkio runtime actor and HTTP renderer, and produce a validated Linux Development package for Tokkio. Use for CC5-to-Unreal, CC5-to-ACE, CC5-to-Tokkio, Reallusion Auto Setup, ARKit 52 mapping, ACE Unreal Renderer, Tokkio avatar preparation, Unreal Linux cross-compilation, Cook/Pak/Archive, or Tokkio Linux packaging tasks.
---

# Build a CC5 Tokkio Avatar

Build and verify the complete CC5 → Unreal Engine → NVIDIA ACE/Tokkio renderer pipeline. Treat each verification gate as mandatory; do not claim success from UI clicks alone.

## Gather paths

Resolve these values from the user or workspace before changing anything:

- CC5 export directory
- Unreal project root and `.uproject`
- Unreal Engine root and exact version
- desired Unreal asset path, module name, and map path
- locations of Reallusion Auto Setup and NVIDIA ACE Renderer packages

Default to UE 5.5.4 only when the installed ACE package explicitly targets UE 5.5. Keep downloaded package versions and engine versions aligned.

## Read the relevant references

- Read [references/export-import.md](references/export-import.md) before operating CC5 or importing with Reallusion Auto Setup.
- Read [references/prerequisites.md](references/prerequisites.md) when installing or checking Unreal, Visual Studio, Reallusion, or NVIDIA components.
- Read [references/ace-cc5-mapping.md](references/ace-cc5-mapping.md) before implementing or reviewing facial mapping.
- Read [references/runtime-integration.md](references/runtime-integration.md) before creating the native actor, map, camera, lighting, or HTTP renderer setup.
- Read [references/linux-packaging.md](references/linux-packaging.md) before installing a Linux cross-compile SDK or producing a Tokkio Linux package.
- Read [references/troubleshooting.md](references/troubleshooting.md) after any failed import, build, headless command, or visual verification.

## Stage 1: verify prerequisites

Run:

```powershell
./scripts/check-unreal-project.ps1 -ProjectRoot <project-root> -EngineRoot <engine-root>
```

Add `-RequireLinux` when Linux/Tokkio packaging is in scope.

Require:

- compatible Unreal Engine installation
- Visual Studio 2022 C++ game development workload
- MSVC v143 14.38 for the validated UE 5.5 setup
- Windows SDK 10.0.22621 or a compatible installed SDK
- Linux Target Platform when Linux/Tokkio packaging is required
- Reallusion Auto Setup matching the UE version
- NVIDIA ACE Reference, HTTP API, and Stream Helper plugins matching the UE version

Do not install software or accept login/permission prompts without following the active Computer Use confirmation policy.

## Stage 2: export from CC5

Use the Computer Use skill for CC5 GUI work when available. Follow the settings and checks in `references/export-import.md`.

Export a complete bundle containing:

- one non-empty FBX
- a matching Reallusion JSON sidecar
- all referenced textures
- an extended facial profile containing the ARKit-compatible expressions

Then run:

```powershell
./scripts/check-cc5-export.ps1 -ExportDir <export-directory>
```

Stop if FBX/JSON files are missing, empty, mismatched, or textures referenced by JSON are absent. Check sibling `.fbm` folders before concluding that an export failed.

## Stage 3: prepare the Unreal project

Create or use a C++ Unreal project. Keep all third-party plugin versions compatible with the engine.

Enable these plugins in the `.uproject`:

- `RLPlugin`
- `NV_ACE_Reference`
- `ACEUnrealRendererStreamHelper`
- `ACEUnrealRendererHttpAPI`

Copy the Reallusion Auto Setup project files exactly as its installation guide specifies. Copy ACE Renderer plugin folders into `<ProjectRoot>/Plugins` unless the package documentation requires engine installation.

Build the Editor target before launching Unreal:

```powershell
./scripts/build-unreal.ps1 -ProjectRoot <project-root> -EngineRoot <engine-root> -Target Editor
```

## Stage 4: import with Reallusion Auto Setup

Import the FBX through Reallusion Auto Setup, not plain FBX import alone.

- Select the Unreal/CC character import mode.
- Keep Auto Setup enabled.
- Disable Control Rig unless the user needs body-control authoring.
- In Unreal FBX options, explicitly enable **Import Morph Targets**.
- Import all meshes, skeleton, materials, textures, physics, and Reallusion profile assets.

Save the imported package, then run the Unreal Python verifier:

```powershell
UnrealEditor-Cmd.exe <project.uproject> -ExecutePythonScript=<skill>/scripts/verify-cc5-morphs.py -Unattended -NoSplash -NoSound -Log
```

Set `CC5_MESH_PATH` when the skeletal mesh is not `/Game/CC5.CC5`.

Require all 52 ACE inputs to have CC5 targets. A larger morph count is expected; the validated character had 249 morph targets, but do not use 249 as a universal requirement.

## Stage 5: implement ACE mapping and runtime actor

Use `references/ace-cc5-mapping.md` as the authoritative mapping table.

Prefer a project-owned runtime actor over modifying vendor plugin sources. The actor must:

1. own the CC5 skeletal mesh and `UACEAudioCurveSourceComponent`;
2. register itself with `UACEUnrealRendererStreamHelperLibrary::SetActor(this)` in `BeginPlay`;
3. clear the registration in `EndPlay`;
4. read the 52 ACE weights every tick;
5. write them to CC5 morph targets, duplicating `BrowInnerUp` and `CheekPuff` to left and right targets;
6. set a stable Tokkio camera and lighting rig;
7. set the local player view target for Play verification.

Add `ACERuntime` and `ACEUnrealRendererStreamHelper` to the runtime module dependencies. Use the implementation pattern in `references/runtime-integration.md`.

Only patch `AnimNode_ApplyACEAnimation.cpp` when the project intentionally uses the ACE animation node and cannot use the project-owned actor mapping. Keep a documented patch because plugin upgrades overwrite vendor edits.

## Stage 6: create and configure the level

Run `scripts/create-cc5-tokkio-level.py` with these optional environment variables:

- `CC5_TOKKIO_LEVEL` (default `/Game/Maps/L_CC5_Tokkio`)
- `CC5_TOKKIO_ACTOR_CLASS` (default `/Script/cc5_tokkio.CC5TokkioAvatar`)

Run the level creation with a normal GPU renderer when spawning camera or light components. Do not use `-NullRHI` for this step; it caused a divide-by-zero crash in the validated UE 5.5 workflow.

Set both `EditorStartupMap` and `GameDefaultMap` to the created map. Rebuild Editor and Game targets after C++ changes.

## Stage 7: verify end to end

Open the project and run Play. Verify visually:

- correct default map
- one avatar actor
- front-facing head-and-shoulders framing
- no editor proxy meshes or light geometry in the game view
- usable skin, eye, clothing, and facial materials
- neutral face before an ACE stream arrives

While Play is running, verify:

```powershell
Invoke-WebRequest http://127.0.0.1:8021/health -UseBasicParsing
```

Require HTTP 200 and `Health Check Successful`. Then build the game target and verify the generated executable exists.

Do not claim live Tokkio completion until a real Tokkio service, stream ID, and renderer stream request have been tested. Local `/health` success proves the Unreal renderer HTTP service, not the upstream Tokkio deployment.

## Stage 8: package for Linux Tokkio

Follow `references/linux-packaging.md`. Close Unreal Editor and Live Coding, then run:

```powershell
./scripts/package-linux.ps1 `
  -ProjectRoot <project-root> `
  -EngineRoot <engine-root> `
  -ArchiveDirectory <project-root>\dist\Linux
```

The script must:

1. require a valid Unreal Linux cross-compile SDK;
2. build `Linux Development`, never Shipping for the validated ACE plugin set;
3. disable both UBA and UBALocal for the Linux target;
4. reuse the installed Editor for Cook instead of rebuilding the Reallusion Editor-only plugin;
5. Cook, Stage, Pak, and Archive all maps;
6. verify the launch script, ELF magic, `.pak`, `.ucas`, `.utoc`, and ACE Linux runtime files.

If native component types or default-subobject classes changed after the map was saved, recreate or respawn the avatar actor and save the map before Cook. Treat any `Failed import` in the Cook summary as a blocker.

## Completion report

Report concrete evidence:

- export FBX/JSON/texture paths and sizes
- imported skeletal mesh path and morph count
- plugin names and versions
- mapping coverage and missing targets
- map path and actor class
- Editor and Game build results
- `/health` status
- Linux SDK status and toolchain version
- Linux archive path, total size, ELF verification, and Pak/IoStore files
- any remaining requirement for Tokkio service credentials, stream ID, container deployment, or Linux host validation
