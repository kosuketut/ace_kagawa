import os
import unreal


mesh_path = os.environ.get("CC5_MESH_PATH", "/Game/CC5.CC5")
mesh = unreal.load_asset(mesh_path)

if mesh is None:
    raise RuntimeError(f"CC5_VERIFY: skeletal mesh was not found: {mesh_path}")

if hasattr(mesh, "get_all_morph_target_names"):
    names = [str(name) for name in mesh.get_all_morph_target_names()]
elif hasattr(mesh, "get_morph_targets"):
    names = [target.get_name() for target in mesh.get_morph_targets()]
else:
    raise RuntimeError("CC5_VERIFY: no supported morph-target accessor was found")

required = {
    "Eye_Blink_L", "Eye_L_Look_Down", "Eye_L_Look_R", "Eye_L_Look_L", "Eye_L_Look_Up",
    "Eye_Squint_L", "Eye_Wide_L", "Eye_Blink_R", "Eye_R_Look_Down", "Eye_R_Look_L",
    "Eye_R_Look_R", "Eye_R_Look_Up", "Eye_Squint_R", "Eye_Wide_R", "Jaw_Forward",
    "Jaw_L", "Jaw_R", "Jaw_Open", "Mouth_Close", "Mouth_Funnel", "Mouth_Pucker",
    "Mouth_L", "Mouth_R", "Mouth_Smile_L", "Mouth_Smile_R", "Mouth_Frown_L",
    "Mouth_Frown_R", "Mouth_Dimple_L", "Mouth_Dimple_R", "Mouth_Stretch_L",
    "Mouth_Stretch_R", "Mouth_Roll_In_Lower", "Mouth_Roll_In_Upper", "Mouth_Shrug_Lower",
    "Mouth_Shrug_Upper", "Mouth_Press_L", "Mouth_Press_R", "Mouth_Down_Lower_L",
    "Mouth_Down_Lower_R", "Mouth_Up_Upper_L", "Mouth_Up_Upper_R", "Brow_Drop_L",
    "Brow_Drop_R", "Brow_Raise_Inner_L", "Brow_Raise_Inner_R", "Brow_Raise_Outer_L",
    "Brow_Raise_Outer_R", "Cheek_Puff_L", "Cheek_Puff_R", "Cheek_Raise_L",
    "Cheek_Raise_R", "Nose_Sneer_L", "Nose_Sneer_R", "Tongue_Out",
}

missing = sorted(required.difference(names))
unreal.log(f"CC5_VERIFY: mesh={mesh_path}")
unreal.log(f"CC5_VERIFY: morph_count={len(names)}")
unreal.log(f"CC5_VERIFY: required_count={len(required)}")
unreal.log(f"CC5_VERIFY: missing_count={len(missing)}")
unreal.log(f"CC5_VERIFY: missing={'|'.join(missing)}")
unreal.log(f"CC5_VERIFY: morph_names={'|'.join(sorted(names))}")

if missing:
    raise RuntimeError(f"CC5_VERIFY: required CC5 morph targets are missing: {missing}")

