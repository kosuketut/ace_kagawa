[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)]
    [string]$ProjectRoot,

    [string]$EngineRoot = 'C:\Program Files\Epic Games\UE_5.5',

    [switch]$RequireLinux,

    [switch]$TestHealth
)

$ErrorActionPreference = 'Stop'
$root = (Resolve-Path -LiteralPath $ProjectRoot).Path
$uprojects = @(Get-ChildItem -LiteralPath $root -Filter *.uproject -File)
$issues = [System.Collections.Generic.List[string]]::new()

if ($uprojects.Count -ne 1) {
    $issues.Add("Expected exactly one .uproject at the project root; found $($uprojects.Count).")
}

$projectData = $null
if ($uprojects.Count -eq 1) {
    $projectData = Get-Content -LiteralPath $uprojects[0].FullName -Raw | ConvertFrom-Json
}

$requiredPlugins = @('RLPlugin', 'NV_ACE_Reference', 'ACEUnrealRendererStreamHelper', 'ACEUnrealRendererHttpAPI')
$pluginState = [ordered]@{}
foreach ($plugin in $requiredPlugins) {
    $declared = @($projectData.Plugins | Where-Object { $_.Name -eq $plugin -and $_.Enabled }).Count -gt 0
    $directory = Test-Path -LiteralPath (Join-Path $root "Plugins\$plugin")
    $pluginState[$plugin] = [ordered]@{ enabled = $declared; project_directory = $directory }
    if (-not $declared) { $issues.Add("Plugin is not enabled in .uproject: $plugin") }
    if (-not $directory) { $issues.Add("Project plugin directory is missing: Plugins\$plugin") }
}

$buildBat = Join-Path $EngineRoot 'Engine\Build\BatchFiles\Build.bat'
if (-not (Test-Path -LiteralPath $buildBat)) { $issues.Add("Unreal Build.bat is missing: $buildBat") }

$linuxSdk = $null
if ($RequireLinux) {
    $runUat = Join-Path $EngineRoot 'Engine\Build\BatchFiles\RunUAT.bat'
    if (-not (Test-Path -LiteralPath $runUat)) {
        $issues.Add("Unreal RunUAT.bat is missing: $runUat")
    } else {
        $machineLinuxRoot = [Environment]::GetEnvironmentVariable('LINUX_MULTIARCH_ROOT', 'Machine')
        if ($machineLinuxRoot) { $env:LINUX_MULTIARCH_ROOT = $machineLinuxRoot }
        $turnkeyOutput = @(& $runUat Turnkey -command=VerifySdk -platform=Linux -utf8output 2>&1)
        $turnkeyText = $turnkeyOutput -join [Environment]::NewLine
        $linuxSdk = [ordered]@{
            linux_multiarch_root = $machineLinuxRoot
            valid = ($turnkeyText -match 'Linux:\s+\(Status=Valid')
            details = @($turnkeyOutput | Where-Object { "$_" -match '^Linux:' } | ForEach-Object { "$_" })
        }
        if ($LASTEXITCODE -ne 0 -or -not $linuxSdk.valid) {
            $issues.Add('Unreal Linux cross-compile SDK is not valid. Run Turnkey VerifySdk and install its Allowed_Sdk version.')
        }
    }
}

$msvcRoots = @(Get-ChildItem -LiteralPath 'C:\Program Files\Microsoft Visual Studio\2022' -Directory -ErrorAction SilentlyContinue |
    ForEach-Object { Get-ChildItem -LiteralPath (Join-Path $_.FullName 'VC\Tools\MSVC') -Directory -ErrorAction SilentlyContinue })
$msvc1438 = @($msvcRoots | Where-Object Name -Like '14.38*')
if ($msvc1438.Count -eq 0) { $issues.Add('MSVC v143 14.38 was not found.') }

$sdkRoot = 'C:\Program Files (x86)\Windows Kits\10\Include\10.0.22621.0'
if (-not (Test-Path -LiteralPath $sdkRoot)) { $issues.Add('Windows SDK 10.0.22621.0 was not found.') }

$health = $null
if ($TestHealth) {
    try {
        $response = Invoke-WebRequest -Uri 'http://127.0.0.1:8021/health' -UseBasicParsing -TimeoutSec 10
        $health = [ordered]@{ status = $response.StatusCode; body = $response.Content }
    } catch {
        $health = [ordered]@{ status = $null; error = $_.Exception.Message }
        $issues.Add('ACE renderer health endpoint did not respond successfully.')
    }
}

$result = [ordered]@{
    project_root = $root
    uproject = if ($uprojects.Count -eq 1) { $uprojects[0].FullName } else { $null }
    engine_root = $EngineRoot
    build_bat = $buildBat
    plugins = $pluginState
    msvc_14_38 = @($msvc1438.FullName)
    windows_sdk_10_0_22621 = (Test-Path -LiteralPath $sdkRoot)
    linux_sdk = $linuxSdk
    health = $health
    issues = @($issues)
    success = ($issues.Count -eq 0)
}

$result | ConvertTo-Json -Depth 7
if ($issues.Count -ne 0) { exit 1 }
