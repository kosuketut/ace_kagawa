import os
import unreal


level_path = os.environ.get("CC5_TOKKIO_LEVEL", "/Game/Maps/L_CC5_Tokkio")
actor_class_path = os.environ.get(
    "CC5_TOKKIO_ACTOR_CLASS", "/Script/cc5_tokkio.CC5TokkioAvatar"
)

level_subsystem = unreal.get_editor_subsystem(unreal.LevelEditorSubsystem)
if unreal.EditorAssetLibrary.does_asset_exist(level_path):
    if not level_subsystem.load_level(level_path):
        raise RuntimeError(f"Failed to load {level_path}")
else:
    if not level_subsystem.new_level(level_path):
        raise RuntimeError(f"Failed to create {level_path}")

avatar_class = unreal.load_class(None, actor_class_path)
if avatar_class is None:
    raise RuntimeError(f"Avatar class was not found: {actor_class_path}")

for actor in unreal.EditorLevelLibrary.get_all_level_actors():
    if actor.get_class() == avatar_class:
        unreal.EditorLevelLibrary.destroy_actor(actor)

avatar = unreal.EditorLevelLibrary.spawn_actor_from_class(
    avatar_class,
    unreal.Vector(0.0, 0.0, 0.0),
    unreal.Rotator(0.0, 0.0, 0.0),
)
if avatar is None:
    raise RuntimeError("Failed to spawn the Tokkio avatar actor")

avatar.set_actor_label("CC5_Tokkio_Avatar")
if not unreal.EditorLoadingAndSavingUtils.save_current_level():
    raise RuntimeError(f"Failed to save {level_path}")

unreal.log(f"CC5_LEVEL: created={level_path}")
unreal.log(f"CC5_LEVEL: actor_class={avatar.get_class().get_path_name()}")
unreal.log(f"CC5_LEVEL: actor_label={avatar.get_actor_label()}")
