[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)]
    [string]$ProjectRoot,

    [string]$EngineRoot = 'C:\Program Files\Epic Games\UE_5.5',

    [ValidateSet('Editor', 'Game', 'Both')]
    [string]$Target = 'Both'
)

$ErrorActionPreference = 'Stop'
$root = (Resolve-Path -LiteralPath $ProjectRoot).Path
$uproject = @(Get-ChildItem -LiteralPath $root -Filter *.uproject -File)
if ($uproject.Count -ne 1) { throw "Expected one .uproject at $root; found $($uproject.Count)." }

$project = Get-Content -LiteralPath $uproject[0].FullName -Raw | ConvertFrom-Json
$moduleName = @($project.Modules | Where-Object Type -EQ 'Runtime' | Select-Object -First 1 -ExpandProperty Name)
if (-not $moduleName) { throw 'No runtime module was found in the .uproject.' }

if (Get-Process UnrealEditor -ErrorAction SilentlyContinue) {
    throw 'Unreal Editor is running. Close it before linking project/plugin DLLs.'
}

$buildBat = Join-Path $EngineRoot 'Engine\Build\BatchFiles\Build.bat'
if (-not (Test-Path -LiteralPath $buildBat)) { throw "Build.bat not found: $buildBat" }

$targets = switch ($Target) {
    'Editor' { @("${moduleName}Editor") }
    'Game' { @($moduleName) }
    'Both' { @("${moduleName}Editor", $moduleName) }
}

foreach ($buildTarget in $targets) {
    & $buildBat $buildTarget Win64 Development "-Project=$($uproject[0].FullName)" -WaitMutex -NoHotReloadFromIDE
    if ($LASTEXITCODE -ne 0) { throw "Unreal build failed for $buildTarget with exit code $LASTEXITCODE." }
}

