[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)]
    [string]$ProjectRoot,

    [string]$EngineRoot = 'C:\Program Files\Epic Games\UE_5.5',

    [string]$ArchiveDirectory,

    [switch]$Clean,

    [switch]$ValidateOnly
)

$ErrorActionPreference = 'Stop'

function Invoke-NativeChecked {
    param(
        [Parameter(Mandatory = $true)]
        [string]$Label,

        [Parameter(Mandatory = $true)]
        [scriptblock]$Command
    )

    & $Command
    if ($LASTEXITCODE -ne 0) {
        throw "$Label failed with exit code $LASTEXITCODE."
    }
}

function Get-PackageValidation {
    param(
        [Parameter(Mandatory = $true)]
        [string]$ArchiveRoot,

        [Parameter(Mandatory = $true)]
        [string]$ModuleName
    )

    $launchScript = Join-Path $ArchiveRoot "$ModuleName.sh"
    $binary = Join-Path $ArchiveRoot "$ModuleName\Binaries\Linux\$ModuleName"
    $paks = Join-Path $ArchiveRoot "$ModuleName\Content\Paks"
    $pak = Join-Path $paks "$ModuleName-Linux.pak"
    $ucas = Join-Path $paks "$ModuleName-Linux.ucas"
    $utoc = Join-Path $paks "$ModuleName-Linux.utoc"
    $aceLinux = Join-Path $ArchiveRoot "$ModuleName\Plugins\NV_ACE_Reference\ThirdParty\Nvigi\Binaries\Linux"

    $elfMagic = $null
    if (Test-Path -LiteralPath $binary) {
        $stream = [System.IO.File]::OpenRead($binary)
        try {
            $bytes = [byte[]]::new(4)
            [void]$stream.Read($bytes, 0, 4)
            $elfMagic = [BitConverter]::ToString($bytes)
        } finally {
            $stream.Dispose()
        }
    }

    $files = if (Test-Path -LiteralPath $ArchiveRoot) {
        @(Get-ChildItem -LiteralPath $ArchiveRoot -File -Recurse)
    } else {
        @()
    }

    $result = [ordered]@{
        archive_root = $ArchiveRoot
        launch_script = $launchScript
        linux_binary = $binary
        elf_magic = $elfMagic
        pak = $pak
        ucas = $ucas
        utoc = $utoc
        ace_linux_runtime = $aceLinux
        file_count = $files.Count
        total_size_bytes = [int64](($files | Measure-Object Length -Sum).Sum)
        success = (
            (Test-Path -LiteralPath $launchScript) -and
            (Test-Path -LiteralPath $binary) -and
            $elfMagic -eq '7F-45-4C-46' -and
            (Test-Path -LiteralPath $pak) -and
            (Test-Path -LiteralPath $ucas) -and
            (Test-Path -LiteralPath $utoc) -and
            (Test-Path -LiteralPath $aceLinux)
        )
    }

    return $result
}

$root = (Resolve-Path -LiteralPath $ProjectRoot).Path
$uprojects = @(Get-ChildItem -LiteralPath $root -Filter *.uproject -File)
if ($uprojects.Count -ne 1) {
    throw "Expected exactly one .uproject at $root; found $($uprojects.Count)."
}

$project = Get-Content -LiteralPath $uprojects[0].FullName -Raw | ConvertFrom-Json
$moduleName = $project.Modules | Where-Object Type -EQ 'Runtime' | Select-Object -First 1 -ExpandProperty Name
if (-not $moduleName) { throw 'No runtime module was found in the .uproject.' }

if (-not $ArchiveDirectory) { $ArchiveDirectory = Join-Path $root 'dist\Linux' }
$archiveRoot = [System.IO.Path]::GetFullPath($ArchiveDirectory)

$runUat = Join-Path $EngineRoot 'Engine\Build\BatchFiles\RunUAT.bat'
$buildBat = Join-Path $EngineRoot 'Engine\Build\BatchFiles\Build.bat'
if (-not (Test-Path -LiteralPath $runUat)) { throw "RunUAT.bat not found: $runUat" }
if (-not (Test-Path -LiteralPath $buildBat)) { throw "Build.bat not found: $buildBat" }

$machineLinuxRoot = [Environment]::GetEnvironmentVariable('LINUX_MULTIARCH_ROOT', 'Machine')
if ($machineLinuxRoot) { $env:LINUX_MULTIARCH_ROOT = $machineLinuxRoot }
$turnkeyOutput = @(& $runUat Turnkey -command=VerifySdk -platform=Linux -utf8output 2>&1)
$turnkeyText = $turnkeyOutput -join [Environment]::NewLine
if ($LASTEXITCODE -ne 0 -or $turnkeyText -notmatch 'Linux:\s+\(Status=Valid') {
    $details = @($turnkeyOutput | Where-Object { "$_" -match '^Linux:' }) -join [Environment]::NewLine
    throw "Linux cross-compile SDK is invalid. $details"
}

$existingValidation = Get-PackageValidation -ArchiveRoot $archiveRoot -ModuleName $moduleName
if ($ValidateOnly) {
    [ordered]@{
        project_root = $root
        uproject = $uprojects[0].FullName
        module = $moduleName
        linux_sdk_root = $machineLinuxRoot
        linux_sdk = @($turnkeyOutput | Where-Object { "$_" -match '^Linux:' } | ForEach-Object { "$_" })
        package = $existingValidation
        success = $true
    } | ConvertTo-Json -Depth 6
    exit 0
}

$blockingProcesses = @(Get-Process UnrealEditor, UnrealEditor-Cmd, LiveCodingConsole -ErrorAction SilentlyContinue)
if ($blockingProcesses.Count -ne 0) {
    $summary = $blockingProcesses | ForEach-Object { "$($_.ProcessName)($($_.Id))" }
    throw "Close Unreal Editor, commandlets, and Live Coding before packaging: $($summary -join ', ')"
}

$commonBuildArgs = @(
    $moduleName,
    'Linux',
    'Development',
    "-Project=$($uprojects[0].FullName)",
    '-NoUBA',
    '-NoUBALocal',
    '-NoXGE',
    '-WaitMutex'
)

if ($Clean) {
    Invoke-NativeChecked -Label 'Linux target clean' -Command {
        & $buildBat @commonBuildArgs -Clean
    }
}

Invoke-NativeChecked -Label 'Linux target build' -Command {
    & $buildBat @commonBuildArgs
}

$linuxBinary = Join-Path $root "Binaries\Linux\$moduleName"
$linuxSymbols = Join-Path $root "Binaries\Linux\$moduleName.sym"
if (-not (Test-Path -LiteralPath $linuxBinary) -or -not (Test-Path -LiteralPath $linuxSymbols)) {
    Invoke-NativeChecked -Label 'Linux target recovery clean' -Command {
        & $buildBat @commonBuildArgs -Clean
    }
    Invoke-NativeChecked -Label 'Linux target recovery build' -Command {
        & $buildBat @commonBuildArgs
    }
}

$uatArgs = @(
    'BuildCookRun',
    '-clientconfig=Development',
    '-serverconfig=Development',
    "-project=$($uprojects[0].FullName)",
    '-utf8output',
    '-nodebuginfo',
    '-allmaps',
    '-noP4',
    '-cook',
    '-build',
    '-nocompileeditor',
    '-ubtargs=-NoUBA -NoUBALocal -NoXGE',
    '-stage',
    '-prereqs',
    '-pak',
    '-archive',
    "-archivedirectory=$archiveRoot",
    '-platform=Linux'
)

Invoke-NativeChecked -Label 'Linux BuildCookRun' -Command {
    & $runUat @uatArgs
}

$validation = Get-PackageValidation -ArchiveRoot $archiveRoot -ModuleName $moduleName
if (-not $validation.success) {
    throw "Linux archive verification failed: $($validation | ConvertTo-Json -Compress -Depth 6)"
}

[ordered]@{
    project_root = $root
    uproject = $uprojects[0].FullName
    module = $moduleName
    linux_sdk_root = $machineLinuxRoot
    linux_sdk = @($turnkeyOutput | Where-Object { "$_" -match '^Linux:' } | ForEach-Object { "$_" })
    package = $validation
    success = $true
} | ConvertTo-Json -Depth 6
