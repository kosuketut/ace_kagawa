[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)]
    [string]$ExportDir,

    [string]$BaseName
)

$ErrorActionPreference = 'Stop'
$resolved = (Resolve-Path -LiteralPath $ExportDir).Path
$fbxFiles = @(Get-ChildItem -LiteralPath $resolved -File | Where-Object Extension -Match '^\.fbx$')

if ($BaseName) {
    $fbx = $fbxFiles | Where-Object BaseName -EQ $BaseName | Select-Object -First 1
} else {
    $fbx = $fbxFiles | Sort-Object Length -Descending | Select-Object -First 1
}

$issues = [System.Collections.Generic.List[string]]::new()
if (-not $fbx) {
    $issues.Add('No FBX was found at the export root. Check sibling .fbm folders.')
}

$jsonFile = $null
$jsonData = $null
if ($fbx) {
    $jsonFile = Get-Item -LiteralPath (Join-Path $resolved ($fbx.BaseName + '.json')) -ErrorAction SilentlyContinue
    if ($fbx.Length -lt 1024) { $issues.Add("FBX is unexpectedly small: $($fbx.Length) bytes") }
    if (-not $jsonFile) {
        $issues.Add("Matching JSON is missing for $($fbx.Name)")
    } else {
        try {
            $jsonData = Get-Content -LiteralPath $jsonFile.FullName -Raw | ConvertFrom-Json
        } catch {
            $issues.Add("JSON is not parseable: $($_.Exception.Message)")
        }
    }
}

$textureFiles = @(Get-ChildItem -LiteralPath $resolved -Recurse -File | Where-Object Extension -Match '^\.(png|jpg|jpeg|tga|bmp|exr)$')
if ($textureFiles.Count -eq 0) { $issues.Add('No texture images were found.') }

$generation = $null
$exportDirectory = $null
if ($jsonData -and $fbx) {
    $root = $jsonData.PSObject.Properties[$fbx.BaseName].Value
    if (-not $root) {
        $root = $jsonData.PSObject.Properties | Select-Object -First 1 -ExpandProperty Value
    }
    $exportDirectory = $root.'Export Directory'
    $objects = @($root.Object.PSObject.Properties)
    if ($objects.Count) { $generation = $objects[0].Value.Generation }
}

$result = [ordered]@{
    export_dir = $resolved
    fbx = if ($fbx) { $fbx.FullName } else { $null }
    fbx_bytes = if ($fbx) { $fbx.Length } else { 0 }
    json = if ($jsonFile) { $jsonFile.FullName } else { $null }
    texture_count = $textureFiles.Count
    generation = $generation
    json_export_directory = $exportDirectory
    issues = @($issues)
    success = ($issues.Count -eq 0)
}

$result | ConvertTo-Json -Depth 5
if ($issues.Count -ne 0) { exit 1 }

